package tests

import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.{BottleDeposit, Item, Sale, SalesTax}

class Task3 extends FunSuite {

  test("enter state test"){
    val testSelfCheckout: SelfCheckout = new SelfCheckout()

    val testItem = new Item("item1", 10.0)

    testSelfCheckout.addItemToStore("123", testItem)

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.displayString() == "")

    assert(testSelfCheckout.itemsInCart().length == 1)
    assert(testSelfCheckout.itemsInCart()(0).description() == "item1")
    assert(math.abs(testSelfCheckout.itemsInCart()(0).price() - 10.0) < .001)

    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.displayString() == "")

    assert(testSelfCheckout.itemsInCart().length == 2)
    assert(testSelfCheckout.itemsInCart()(1).description() == "item1")
    assert(math.abs(testSelfCheckout.itemsInCart()(1).price() - 10.0) < .001)

    testSelfCheckout.clearPressed()

    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.itemsInCart().length == 3)
    assert(testSelfCheckout.itemsInCart()(2).description() == "error")
    assert(math.abs(testSelfCheckout.itemsInCart()(2).price() - 0.0) < .001)

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.creditPressed()
    testSelfCheckout.cashPressed()
    testSelfCheckout.loyaltyCardPressed()

    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.displayString() == "")

    assert(testSelfCheckout.itemsInCart().length == 4)
    assert(testSelfCheckout.itemsInCart()(3).description() == "item1")
    assert(math.abs(testSelfCheckout.itemsInCart()(3).price() - 10.0) < .001)
  }

  test("checkout test"){
    val testSelfCheckout: SelfCheckout = new SelfCheckout()

    val testItem = new Item("item1", 10.0)

    testSelfCheckout.addItemToStore("123", testItem)

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.enterPressed()

    testSelfCheckout.checkoutPressed()
    assert(testSelfCheckout.displayString() == "cash or credit")

    testSelfCheckout.clearPressed()
    assert(testSelfCheckout.displayString() == "cash or credit")

    testSelfCheckout.enterPressed()
    assert(testSelfCheckout.itemsInCart().length == 1)

    testSelfCheckout.cashPressed()
    assert(testSelfCheckout.displayString() == "")
    assert(testSelfCheckout.itemsInCart().isEmpty)

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.enterPressed()

    testSelfCheckout.checkoutPressed()

    testSelfCheckout.creditPressed()
    assert(testSelfCheckout.displayString() == "")
    assert(testSelfCheckout.itemsInCart().isEmpty)


  }

}
