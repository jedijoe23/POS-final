package tests

import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.Item

class Task1 extends FunSuite {

  test("Item creation") {
    val testItem: Item = new Item("item1", 10.0)

    assert(math.abs(testItem.price() - 10.0) < .001)
    assert(testItem.description() == "item1")

    testItem.setBasePrice(15.0)

    assert(math.abs(testItem.price() - 15.0) <.001)
  }


  test("disStr test") {
    val testSelfCheckout: SelfCheckout = new SelfCheckout()

    assert(testSelfCheckout.displayString() == "")

    testSelfCheckout.numberPressed(1)
    assert(testSelfCheckout.displayString() == "1")
    testSelfCheckout.numberPressed(2)
    assert(testSelfCheckout.displayString() == "12")
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.clearPressed()

    assert(testSelfCheckout.displayString() == "")

  }


  test("enter test") {
    val testSelfCheckout: SelfCheckout = new SelfCheckout()

    val testItem = new Item("item1", 10.0)

    testSelfCheckout.addItemToStore("123", testItem)

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.clearPressed()

    assert(testSelfCheckout.displayString() == "")

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.itemsInCart().length == 1)
    assert(testSelfCheckout.itemsInCart()(0).description() == "item1")
    assert(math.abs(testSelfCheckout.itemsInCart()(0).price() - 10.0) < .001)

    assert(testSelfCheckout.displayString() == "")


    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.itemsInCart().length == 2)
    assert(testSelfCheckout.itemsInCart()(1).description() == "error")
    assert(math.abs(testSelfCheckout.itemsInCart()(1).price() - 0.0) < .001)


  }

  test("multiple enter") {
    val testSelfCheckout: SelfCheckout = new SelfCheckout()

    val testItem1 = new Item("item1", 10.0)
    val testItem2 = new Item("item2", 20.0)


    testSelfCheckout.addItemToStore("123", testItem1)
    testSelfCheckout.addItemToStore("321", testItem2)

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")


    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.itemsInCart().length == 1)
    assert(testSelfCheckout.itemsInCart()(0).description() == "item1")
    assert(math.abs(testSelfCheckout.itemsInCart()(0).price() - 10.0) < .001)

    testSelfCheckout.numberPressed(3)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(1)

    assert(testSelfCheckout.displayString() == "321")


    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.itemsInCart().length == 2)
    assert(testSelfCheckout.itemsInCart()(0).description() == "item1")
    assert(math.abs(testSelfCheckout.itemsInCart()(0).price() - 10.0) < .001)

    assert(testSelfCheckout.itemsInCart()(1).description() == "item2")
    assert(math.abs(testSelfCheckout.itemsInCart()(1).price() - 20.0) < .001)



  }
  test("change price after enter"){
    val testSelfCheckout: SelfCheckout = new SelfCheckout()

    val testItem = new Item("item1", 10.0)

    testSelfCheckout.addItemToStore("123", testItem)

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.itemsInCart().length == 1)
    assert(testSelfCheckout.itemsInCart()(0).description() == "item1")
    assert(math.abs(testSelfCheckout.itemsInCart()(0).price() - 10.0) < .001)

    testItem.setBasePrice(15.0)

    assert(testSelfCheckout.itemsInCart().length == 1)
    assert(testSelfCheckout.itemsInCart()(0).description() == "item1")
    assert(math.abs(testSelfCheckout.itemsInCart()(0).price() - 15.0) < .001)
  }

  test("leading zeroes"){
    val testSelfCheckout: SelfCheckout = new SelfCheckout()

    val testItem = new Item("item1", 10.0)

    testSelfCheckout.addItemToStore("003", testItem)

    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "003")

    testSelfCheckout.enterPressed()

    assert(testSelfCheckout.itemsInCart().length == 1)
    assert(testSelfCheckout.itemsInCart()(0).description() == "item1")
    assert(math.abs(testSelfCheckout.itemsInCart()(0).price() - 10.0) < .001)


  }

}
