package tests

import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.{BottleDeposit, Item, Sale, SalesTax}

class Task2 extends FunSuite{

  test("Sale Test"){
    val testItem: Item = new Item("item1", 10.0)

    testItem.addModifier(new Sale(20.0))

    assert(Math.abs(testItem.price() - 8.0) < .001)

    testItem.addModifier(new Sale(10.0))

    assert(Math.abs(testItem.price() - 7.2) < .001)

  }

  test("tax test"){
    val testItem: Item = new Item("item1", 10.0)

    testItem.addModifier(new SalesTax(10.0))

    assert(Math.abs(testItem.tax() - 1.0) < 0.001)

    testItem.addModifier(new SalesTax(8.0))

    assert(Math.abs(testItem.tax() - 1.8) < 0.001)
  }

  test("Deposit test"){
    val testItem: Item = new Item("item1", 10.0)

    testItem.addModifier(new BottleDeposit(0.50))

    assert(Math.abs(testItem.tax() - 0.50) < 0.001)


  }

  test("All together now"){
    val testItem: Item = new Item("item1", 10.0)

    testItem.addModifier(new Sale(20.0))

    assert(Math.abs(testItem.price() - 8.0) < .001)

    testItem.addModifier(new SalesTax(10.0))

    assert(Math.abs(testItem.tax() - 0.8) < 0.001)

    testItem.addModifier(new BottleDeposit(0.50))

    assert(Math.abs(testItem.tax() - 1.30) < 0.001)
  }

  test("checkout test"){
    val testSelfCheckout: SelfCheckout = new SelfCheckout()

    val testItem = new Item("item1", 10.0)

    testSelfCheckout.addItemToStore("123", testItem)

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.enterPressed()

    assert(Math.abs(testSelfCheckout.subtotal() - 10.0) < .001)
    assert(Math.abs(testSelfCheckout.total() - 10.0) < .001)
  }

  test("mod checkout"){
    val testSelfCheckout: SelfCheckout = new SelfCheckout()

    val testItem1 = new Item("item1", 10.0)
    val testItem2 = new Item("item2", 20.0)

    testItem1.addModifier(new Sale(20.0))
    testItem1.addModifier(new SalesTax(10.0))

    testItem2.addModifier(new Sale(20.0))
    testItem2.addModifier(new Sale(25.0))
    testItem2.addModifier(new SalesTax(10.0))


    testSelfCheckout.addItemToStore("123", testItem1)
    testSelfCheckout.addItemToStore("321", testItem2)

    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(3)

    assert(testSelfCheckout.displayString() == "123")

    testSelfCheckout.enterPressed()

    assert(math.abs(testSelfCheckout.subtotal() - 8.0) < .001)
    assert(math.abs(testSelfCheckout.tax() - 0.8) < .001)
    assert(math.abs(testSelfCheckout.total() - 8.8) < .001)

    testSelfCheckout.numberPressed(3)
    testSelfCheckout.numberPressed(2)
    testSelfCheckout.numberPressed(1)

    assert(testSelfCheckout.displayString() == "321")

    testSelfCheckout.enterPressed()

    assert(math.abs(testSelfCheckout.subtotal() - 20.0) < .001)
    assert(math.abs(testSelfCheckout.tax() - 2.0) < .001)
    assert(math.abs(testSelfCheckout.total() - 22.0) < .001)
  }

}
